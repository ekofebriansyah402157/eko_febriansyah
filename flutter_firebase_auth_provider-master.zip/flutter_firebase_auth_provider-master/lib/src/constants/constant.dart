class CONSTANT {
  static const String KEY_BASE_URL = 'KEY_BASE_URL';
}
