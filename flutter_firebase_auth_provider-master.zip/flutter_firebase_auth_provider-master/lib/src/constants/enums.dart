enum AppEnvironmentEnum { STAGING, PRODUCTION }
