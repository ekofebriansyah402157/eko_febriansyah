class TheFontSize {
  static double ultraLarge = 30;
  static double extraLarge = 24;
  static double large = 20;
  static double normal = 16;
  static double small = 14;
  static double extraSmall = 10;
}
