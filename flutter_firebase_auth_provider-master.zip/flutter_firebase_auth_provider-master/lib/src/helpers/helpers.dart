import 'package:flutter/cupertino.dart';

class Helpers {
  static final GlobalKey<NavigatorState> navigatorKey =
      new GlobalKey<NavigatorState>();
}
